<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo "Unauthorized";
    exit();
}

$user_id    = $_SESSION['user_id'];
$upload_dir = __DIR__ . '/../assets/uploads/';

// Create uploads folder if it doesn't exist
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

if (!isset($_FILES['profile_image']) || $_FILES['profile_image']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo "No file uploaded or upload error.";
    exit();
}

$file      = $_FILES['profile_image'];
$mime_type = mime_content_type($file['tmp_name']);
$allowed   = ['image/jpeg', 'image/png', 'image/jpg'];

if (!in_array($mime_type, $allowed)) {
    http_response_code(400);
    echo "Only JPG and PNG files are allowed.";
    exit();
}

if ($file['size'] > 5 * 1024 * 1024) {
    http_response_code(400);
    echo "File size must be under 5MB.";
    exit();
}

// Determine extension from mime type
$ext = ($mime_type === 'image/png') ? 'png' : 'jpg';

// Delete old profile images for this user
foreach (['jpg', 'png', 'jpeg'] as $old_ext) {
    $old_file = $upload_dir . "profile_{$user_id}.{$old_ext}";
    if (file_exists($old_file)) {
        unlink($old_file);
    }
}

// Save new profile image
$filename    = "profile_{$user_id}.{$ext}";
$destination = $upload_dir . $filename;

if (move_uploaded_file($file['tmp_name'], $destination)) {
    http_response_code(200);
    echo "Upload successful.";
} else {
    http_response_code(500);
    echo "Failed to save image. Check folder permissions.";
}
?>