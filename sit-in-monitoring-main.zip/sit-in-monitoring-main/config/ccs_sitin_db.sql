-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2026 at 05:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ccs_sitin_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `laboratory` varchar(100) NOT NULL,
  `time_in` time NOT NULL,
  `reservation_date` date NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `user_id`, `id_number`, `name`, `purpose`, `laboratory`, `time_in`, `reservation_date`, `status`, `created_at`) VALUES
(1, 2, '21418470', 'Ejhie Pacs', 'Java', '530', '03:14:00', '2026-03-27', 'rejected', '2026-03-27 02:14:37'),
(2, 2, '21418470', 'Ejhie Pacs', 'PHP', '530', '03:24:00', '2026-03-27', 'approved', '2026-03-27 02:24:35'),
(3, 2, '21418470', 'Ejhie Pacs', 'ASP.Net', 'Lab 517', '16:16:00', '2026-03-27', 'approved', '2026-03-27 03:16:49'),
(4, 1, '21526785', 'CJ Charles', 'Thesis', '524', '04:37:00', '2026-03-27', 'pending', '2026-03-27 03:38:11');

-- --------------------------------------------------------

--
-- Table structure for table `sit_in`
--

CREATE TABLE `sit_in` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `laboratory` varchar(100) NOT NULL,
  `login_time` time NOT NULL,
  `logout_time` time DEFAULT NULL,
  `login_date` date NOT NULL,
  `status` enum('active','completed','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sit_in`
--

INSERT INTO `sit_in` (`id`, `user_id`, `id_number`, `name`, `purpose`, `laboratory`, `login_time`, `logout_time`, `login_date`, `status`, `created_at`) VALUES
(1, 2, '21418470', 'Ejhie Pacs', 'C Programming', '528', '08:33:41', '09:48:58', '2026-03-27', 'completed', '2026-03-27 00:33:41'),
(2, 2, '21418470', 'Ejhie Pacs', 'Python', '528', '10:26:15', '11:17:53', '2026-03-27', 'completed', '2026-03-27 02:26:15'),
(3, 1, '21526785', 'CJ Charles', 'ASP.Net', '530', '11:34:02', NULL, '2026-03-27', 'active', '2026-03-27 03:34:02'),
(4, 3, '21515010', 'Althea Carpentero', 'PHP', '528', '12:02:33', NULL, '2026-03-27', 'active', '2026-03-27 04:02:33');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `course` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `year_level` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `sessions` int(11) DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `id_number`, `course`, `last_name`, `first_name`, `middle_name`, `year_level`, `email`, `address`, `password`, `sessions`) VALUES
(1, '21526785', 'BSIT', 'Charles', 'CJ', 'R', 3, 'charlescj1203@gmail.com', 'T.Padilla St.,Cebu City', '$2y$10$HmGIdz.M/fmbOLmQLsJ5juM9UFWZoMTaeo3wUDgvjHsb/kpysOGlS', 29),
(2, '21418470', 'BSIT', 'Pacs', 'Ejhie', '', 3, 'ejhiepacquiao108@gmail.com', 'mingla', '$2y$10$JLu9vBZSyuEo4Bbumju8UOHHikODYziXPz3/ScHVjZS.blfdyXuLK', 29),
(3, '21515010', 'BSIT', 'Carpentero', 'Althea', 'Buhawe', 3, 'altheakathleen@gmail.com', 'Capitol, Cebu City', '$2y$10$xbrO3fUjLynh8AT1e43tneQ41HDjZDmLe89EOHjt7wXLfG4tzFaq6', 29);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sit_in`
--
ALTER TABLE `sit_in`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sit_in`
--
ALTER TABLE `sit_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sit_in`
--
ALTER TABLE `sit_in`
  ADD CONSTRAINT `sit_in_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
