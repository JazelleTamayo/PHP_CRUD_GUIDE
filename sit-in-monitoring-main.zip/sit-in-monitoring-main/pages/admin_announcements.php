<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$pageTitle = "Manage Announcements - Admin";
$extraCSS = "admin";
$basePath = "../";
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/admin_navigation.php'; ?>

<?php
require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Handle add announcement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $author = $_POST['author'];
        
        $query = "INSERT INTO announcements (title, content, author) VALUES (:title, :content, :author)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':content', $content);
        $stmt->bindParam(':author', $author);
        
        if ($stmt->execute()) {
            $success = "Announcement added successfully!";
        } else {
            $error = "Failed to add announcement.";
        }
    }
    // Handle delete
    elseif ($_POST['action'] === 'delete') {
        $id = $_POST['id'];
        $query = "DELETE FROM announcements WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $success = "Announcement deleted!";
    }
    // Handle edit
    elseif ($_POST['action'] === 'edit') {
        $id = $_POST['id'];
        $title = $_POST['title'];
        $content = $_POST['content'];
        $author = $_POST['author'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $query = "UPDATE announcements SET title = :title, content = :content, author = :author, is_active = :is_active WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':content', $content);
        $stmt->bindParam(':author', $author);
        $stmt->bindParam(':is_active', $is_active);
        
        if ($stmt->execute()) {
            $success = "Announcement updated!";
        } else {
            $error = "Failed to update announcement.";
        }
    }
}

// Fetch all announcements
$query = "SELECT * FROM announcements ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="admin-container">
    <div class="admin-header">
        <h1><i class="fas fa-bullhorn"></i> Manage Announcements</h1>
        <button class="btn-primary" onclick="openAddModal()">
            <i class="fas fa-plus"></i> New Announcement
        </button>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="announcements-list">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Author</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($announcements as $ann): ?>
                <tr>
                    <td><?php echo $ann['id']; ?></td>
                    <td><?php echo htmlspecialchars($ann['title']); ?></td>
                    <td><?php echo substr(htmlspecialchars($ann['content']), 0, 50); ?>...</td>
                    <td><?php echo htmlspecialchars($ann['author']); ?></td>
                    <td>
                        <span class="status-badge <?php echo $ann['is_active'] ? 'active' : 'inactive'; ?>">
                            <?php echo $ann['is_active'] ? 'Active' : 'Inactive'; ?>
                        </span>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($ann['created_at'])); ?></td>
                    <td>
                        <button onclick="editAnnouncement(<?php echo htmlspecialchars(json_encode($ann)); ?>)" class="btn-edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="deleteAnnouncement(<?php echo $ann['id']; ?>)" class="btn-delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add/Edit Modal -->
<div id="announcementModal" class="modal" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add New Announcement</h3>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <form method="POST" id="announcementForm">
            <input type="hidden" name="action" id="formAction" value="add">
            <input type="hidden" name="id" id="announcementId">
            
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" id="title" required class="form-control">
            </div>
            
            <div class="form-group">
                <label>Content</label>
                <textarea name="content" id="content" required rows="5" class="form-control"></textarea>
            </div>
            
            <div class="form-group">
                <label>Author</label>
                <input type="text" name="author" id="author" value="CCS Admin" class="form-control">
            </div>
            
            <div class="form-group" id="activeStatusGroup" style="display:none;">
                <label>
                    <input type="checkbox" name="is_active" id="isActive"> Active
                </label>
            </div>
            
            <div class="form-buttons">
                <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn-primary">Save Announcement</button>
            </div>
        </form>
    </div>
</div>

<style>
.admin-container {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 8px;
    overflow: hidden;
}

.data-table th,
.data-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.data-table th {
    background: #f5f5f5;
    font-weight: 600;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
}

.status-badge.active {
    background: #d4edda;
    color: #155724;
}

.status-badge.inactive {
    background: #f8d7da;
    color: #721c24;
}

.btn-edit, .btn-delete {
    padding: 5px 10px;
    margin: 0 2px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.btn-edit {
    background: #007bff;
    color: white;
}

.btn-delete {
    background: #dc3545;
    color: white;
}

.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    position: relative;
    background: white;
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    border-radius: 8px;
}

.form-group {
    margin-bottom: 15px;
}

.form-control {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.form-buttons {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
    margin-top: 20px;
}
</style>

<script>
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Add New Announcement';
    document.getElementById('formAction').value = 'add';
    document.getElementById('announcementId').value = '';
    document.getElementById('title').value = '';
    document.getElementById('content').value = '';
    document.getElementById('author').value = 'CCS Admin';
    document.getElementById('activeStatusGroup').style.display = 'none';
    document.getElementById('announcementModal').style.display = 'block';
}

function editAnnouncement(ann) {
    document.getElementById('modalTitle').textContent = 'Edit Announcement';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('announcementId').value = ann.id;
    document.getElementById('title').value = ann.title;
    document.getElementById('content').value = ann.content;
    document.getElementById('author').value = ann.author;
    document.getElementById('isActive').checked = ann.is_active == 1;
    document.getElementById('activeStatusGroup').style.display = 'block';
    document.getElementById('announcementModal').style.display = 'block';
}

function deleteAnnouncement(id) {
    if (confirm('Are you sure you want to delete this announcement?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function closeModal() {
    document.getElementById('announcementModal').style.display = 'none';
}
</script>

<?php include '../includes/footer.php'; ?>