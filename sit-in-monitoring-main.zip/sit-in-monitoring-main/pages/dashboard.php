<?php
// ─── sit-in-monitoring/pages/dashboard.php ───────────────────────────────────
session_start();

// Auth guard — redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?error=" . urlencode("Please login first"));
    exit();
}

$pageTitle = "Dashboard - CCS Sit-in System";
$extraCSS = "dashboard";
$basePath = "../";   // pages/ is one level deep, so assets/ is ../assets/

// ─── PATH NOTE ───────────────────────────────────────────────────────────────
// This file lives in: sit-in-monitoring/pages/dashboard.php
//
//  includes/  →  ../includes/
//  assets/    →  ../assets/
//  process/   →  ../process/
//
// All include/require use __DIR__ so they resolve correctly regardless of
// the PHP working directory.
// ─────────────────────────────────────────────────────────────────────────────
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/user_navigation.php'; ?>

<!-- ── SUCCESS MODAL ──────────────────────────────────────────────────────── -->
<?php if (isset($_GET['success'])): ?>
    <div class="modal-overlay" id="successModal">
        <div class="modal-container">
            <div class="modal-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2 class="modal-title">Login Successful!</h2>
            <p class="modal-message"><?php echo htmlspecialchars($_GET['success']); ?></p>

            <div class="modal-user-info">
                <div class="modal-info-item">
                    <i class="fas fa-id-card"></i>
                    <span><?php echo htmlspecialchars($_SESSION['id_number']); ?></span>
                </div>
                <div class="modal-info-item">
                    <i class="fas fa-user"></i>
                    <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                </div>
                <div class="modal-info-item">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo htmlspecialchars($_SESSION['user_email']); ?></span>
                </div>
            </div>

            <button class="modal-btn" onclick="closeModal()">
                <i class="fas fa-check"></i> OK, Got It!
            </button>
        </div>
    </div>

    <script>
        function closeModal() {
            document.getElementById('successModal').style.display = 'none';
            const url = new URL(window.location.href);
            url.searchParams.delete('success');
            window.history.replaceState({}, document.title, url.toString());
        }
        window.addEventListener('click', function (e) {
            const modal = document.getElementById('successModal');
            if (e.target === modal) closeModal();
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeModal();
        });
    </script>
<?php endif; ?>

<!-- ── MAIN DASHBOARD ──────────────────────────────────────────────────────── -->
<div class="dashboard-container">
    <div class="dashboard-main">

        <!-- Page header -->
        <div class="dashboard-header">
            <h1>Student Portal</h1>
            <div class="date-badge">
                <i class="far fa-calendar-alt"></i>
                <?php echo date('F j, Y'); ?>
            </div>
        </div>

        <!-- Two-column grid -->
        <div class="dashboard-grid">

            <!-- ── LEFT COLUMN: Student Info Card ─────────────────────────── -->
            <div class="grid-left">
                <div class="card student-card">

                    <!-- Profile header -->
                    <div class="profile-header">
                        <div class="profile-image-wrapper">
                            <div class="profile-image">
                                <?php
                                $upload_dir = __DIR__ . '/../assets/uploads/';
                                $upload_url = '../assets/uploads/';
                                $user_id = $_SESSION['user_id'];
                                $image_found = false;

                                if (!file_exists($upload_dir)) {
                                    mkdir($upload_dir, 0777, true);
                                }

                                foreach (['jpg', 'png', 'jpeg'] as $ext) {
                                    $file = "profile_{$user_id}.{$ext}";
                                    if (file_exists($upload_dir . $file)) {
                                        echo '<img src="' . $upload_url . $file . '?v=' . time() . '" alt="Profile" id="profileImage">';
                                        $image_found = true;
                                        break;
                                    }
                                }

                                if (!$image_found) {
                                    echo '<i class="fas fa-user-circle"></i>';
                                }
                                ?>
                            </div>
                            <!-- Camera overlay -->
                            <div class="profile-upload-overlay"
                                onclick="document.getElementById('profileUpload').click();" title="Change photo">
                                <i class="fas fa-camera"></i>
                            </div>
                            <!-- Upload form — action points to process/ folder -->
                            <form id="uploadForm" action="../process/upload_profile.php" method="POST"
                                enctype="multipart/form-data">
                                <input type="file" name="profile_image" id="profileUpload"
                                    accept="image/jpeg,image/png,image/jpg" style="display:none;"
                                    onchange="uploadProfileImage()">
                            </form>
                        </div>

                        <div class="profile-info">
                            <h3 class="profile-name">
                                <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </h3>
                            <p class="profile-course">
                                <?php echo isset($_SESSION['course'])
                                    ? htmlspecialchars($_SESSION['course'])
                                    : 'BSIT'; ?>
                                &ndash; Year
                                <?php echo isset($_SESSION['year_level'])
                                    ? htmlspecialchars($_SESSION['year_level'])
                                    : '3'; ?>
                            </p>
                            <p class="profile-id">
                                ID: <?php echo htmlspecialchars($_SESSION['id_number']); ?>
                            </p>
                        </div>
                    </div><!-- /.profile-header -->

                    <!-- Card header -->
                    <div class="card-header">
                        <div class="card-title">
                            <i class="fas fa-user-graduate"></i>
                            <h2>Student Information</h2>
                        </div>
                        <span class="card-date"><?php echo date('Y-M-d'); ?></span>
                    </div>

                    <!-- Card body -->
                    <div class="card-body">
                        <div class="info-row">
                            <span class="info-label">Name</span>
                            <span class="info-value"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Course</span>
                            <span class="info-value">
                                <?php echo isset($_SESSION['course'])
                                    ? htmlspecialchars($_SESSION['course'])
                                    : 'BSIT'; ?>
                            </span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Year</span>
                            <span class="info-value">
                                <?php echo isset($_SESSION['year_level'])
                                    ? htmlspecialchars($_SESSION['year_level'])
                                    : '3'; ?>
                            </span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email</span>
                            <span class="info-value"><?php echo htmlspecialchars($_SESSION['user_email']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Address</span>
                            <span class="info-value">
                                <?php echo isset($_SESSION['address'])
                                    ? htmlspecialchars($_SESSION['address'])
                                    : '—'; ?>
                            </span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Sessions</span>
                            <span class="info-value">
                                <?php echo isset($_SESSION['sessions_remaining'])
                                    ? htmlspecialchars($_SESSION['sessions_remaining'])
                                    : '30'; ?>
                            </span>
                        </div>
                    </div><!-- /.card-body -->

                    <div class="card-footer">
                        <i class="fas fa-user-shield"></i>
                        <span>CCS Admin &mdash; <?php echo date('Y-M-d'); ?></span>
                    </div>

                </div><!-- /.student-card -->
            </div><!-- /.grid-left -->

            <!-- ── RIGHT COLUMN: Announcement + Rules ─────────────────────── -->
            <div class="grid-right">

                <!-- Announcement Card -->
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <i class="fas fa-bullhorn"></i>
                            <h2>Announcement</h2>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="announcement-meta">
                            <span class="author">
                                <i class="fas fa-user-shield"></i>
                                CCS Admin &nbsp;|&nbsp; <?php echo date('Y-M-d'); ?>
                            </span>
                        </div>
                        <p class="announcement-content">
                            Important Announcement &mdash; We are excited to announce the launch of
                            our new website! 🎉 Explore our latest products and services now!
                        </p>
                    </div>
                </div><!-- /.card (announcement) -->

                <!-- Rules Card -->
                <div class="card rules-card" style="margin-top: 20px;">
                    <div class="card-header">
                        <div class="card-title">
                            <i class="fas fa-gavel"></i>
                            <h2>Rules and Regulation</h2>
                        </div>
                    </div>
                    <div class="card-body rules-scroll">

                        <h3 class="university-name">University of Cebu</h3>
                        <h4 class="college-name">COLLEGE OF INFORMATION &amp; COMPUTER STUDIES</h4>
                        <h5 class="rules-subtitle">LABORATORY RULES AND REGULATIONS</h5>

                        <p class="rules-intro">
                            To avoid embarrassment and maintain camaraderie with your friends and
                            superiors at our laboratories, please observe the following:
                        </p>

                        <ol class="rules-list">
                            <li>Maintain silence, proper decorum, and discipline inside the laboratory.
                                Mobile phones, walkmans and other personal pieces of equipment must be
                                switched off.</li>
                            <li>Games are not allowed inside the lab. This includes computer-related
                                games, card games and other games that may disturb the operation of
                                the lab.</li>
                            <li>Surfing the Internet is allowed only with the permission of the
                                instructor. Downloading and installing of software are strictly
                                prohibited.</li>
                            <li>Getting access to other websites not related to the course (especially
                                pornographic and illicit sites) is strictly prohibited.</li>
                            <li>Deleting computer files and changing the set-up of the computer is a
                                major offense.</li>
                            <li>Observe computer time usage carefully. A fifteen-minute allowance is
                                given for each use. Otherwise, the unit will be given to those who
                                wish to "sit-in".</li>
                            <li>Observe proper decorum while inside the laboratory.
                                <ul class="sublist">
                                    <li>Do not get inside the lab unless the instructor is present.</li>
                                    <li>All bags, knapsacks, and the likes must be deposited at the counter.</li>
                                    <li>Follow the seating arrangement of your instructor.</li>
                                    <li>At the end of class, all software programs must be closed.</li>
                                    <li>Return all chairs to their proper places after using.</li>
                                </ul>
                            </li>
                            <li>Chewing gum, eating, drinking, smoking, and other forms of vandalism
                                are prohibited inside the lab.</li>
                            <li>Anyone causing a continual disturbance will be asked to leave the lab.
                                Acts or gestures offensive to the members of the community, including
                                public display of physical intimacy, are not tolerated.</li>
                            <li>Persons exhibiting hostile or threatening behavior such as yelling,
                                swearing, or disregarding requests made by lab personnel will be
                                asked to leave the lab.</li>
                            <li>For serious offense, the lab personnel may call the Civil Security
                                Office (CSU) for assistance.</li>
                            <li>Any technical problem or difficulty must be addressed to the laboratory
                                supervisor, student assistant or instructor immediately.</li>
                        </ol>

                        <div class="disciplinary-section">
                            <h5 class="disciplinary-title">Disciplinary Action</h5>
                            <ul class="disciplinary-list">
                                <li><strong>First Offense</strong> &mdash; The Head or the Dean or OIC
                                    recommends to the Guidance Center for a suspension from classes
                                    for each offender.</li>
                                <li><strong>Second and Subsequent Offenses</strong> &mdash; A
                                    recommendation for a heavier sanction will be endorsed to the
                                    Guidance Center.</li>
                            </ul>
                        </div>

                    </div><!-- /.rules-scroll -->
                </div><!-- /.rules-card -->

            </div><!-- /.grid-right -->
        </div><!-- /.dashboard-grid -->
    </div><!-- /.dashboard-main -->
</div><!-- /.dashboard-container -->

<!-- ── PROFILE UPLOAD SCRIPT ──────────────────────────────────────────────── -->
<script>
    function uploadProfileImage() {
        const form = document.getElementById('uploadForm');
        const overlay = document.querySelector('.profile-upload-overlay');
        const saved = overlay.innerHTML;

        overlay.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        overlay.style.pointerEvents = 'none';

        const xhr = new XMLHttpRequest();
        xhr.open('POST', form.action, true);

        xhr.onload = function () {
            overlay.innerHTML = saved;
            overlay.style.pointerEvents = 'auto';
            if (xhr.status === 200) location.reload();
        };

        xhr.onerror = function () {
            overlay.innerHTML = saved;
            overlay.style.pointerEvents = 'auto';
        };

        xhr.send(new FormData(form));
    }
</script>

<?php include '../includes/footer.php'; ?>