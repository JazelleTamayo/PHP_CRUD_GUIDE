<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php?error=" . urlencode("Unauthorized access"));
    exit();
}

require_once __DIR__ . '/../config/database.php';

$pageTitle = "Sit-in Reports - CCS Sit-in System";
$basePath = "../";

// ── FILTER PARAMETERS ─────────────────────────────────────────────────────
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$purpose = $_GET['purpose'] ?? '';
$laboratory = $_GET['laboratory'] ?? '';
$status = $_GET['status'] ?? '';

// ── BUILD WHERE CLAUSE ─────────────────────────────────────────────────────
$where = [];
$params = [];

if (!empty($date_from) && !empty($date_to)) {
    $where[] = "s.login_date BETWEEN ? AND ?";
    $params[] = $date_from;
    $params[] = $date_to;
}
if (!empty($purpose)) {
    $where[] = "s.purpose = ?";
    $params[] = $purpose;
}
if (!empty($laboratory)) {
    $where[] = "s.laboratory = ?";
    $params[] = $laboratory;
}
if (!empty($status)) {
    $where[] = "s.status = ?";
    $params[] = $status;
}

$whereSql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

// ── FETCH REPORT DATA ──────────────────────────────────────────────────────
$sql = "
    SELECT 
        s.id,
        s.id_number,
        s.name,
        s.purpose,
        s.laboratory,
        s.login_time,
        s.logout_time,
        s.login_date,
        s.status,
        s.reward_points_given,
        u.course,
        u.year_level,
        TIMESTAMPDIFF(MINUTE, s.login_time, s.logout_time) as duration_minutes
    FROM sit_in s
    JOIN users u ON s.user_id = u.id
    $whereSql
    ORDER BY s.login_date DESC, s.login_time DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// ── STATISTICS ─────────────────────────────────────────────────────────────
$total_records = count($reports);
$total_duration = 0;
$total_reward_points = 0;

foreach ($reports as $r) {
    $total_duration += (int) $r['duration_minutes'];
    $total_reward_points += (int) $r['reward_points_given'];
}

$completed_count = count(array_filter($reports, fn($r) => $r['status'] === 'completed'));
$active_count = count(array_filter($reports, fn($r) => $r['status'] === 'active'));

// ── GET UNIQUE VALUES FOR FILTERS ──────────────────────────────────────────
$purposes = $pdo->query("SELECT DISTINCT purpose FROM sit_in WHERE purpose IS NOT NULL ORDER BY purpose")->fetchAll();
$laboratories = $pdo->query("SELECT DISTINCT laboratory FROM sit_in WHERE laboratory IS NOT NULL ORDER BY laboratory")->fetchAll();

// ── HANDLE EXPORT ──────────────────────────────────────────────────────────
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];

    $filter_params = $_GET;
    unset($filter_params['export']);
    $filter_query = http_build_query($filter_params);

    if ($export_type === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="sit_in_report_' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
        fputcsv($output, ['ID', 'ID Number', 'Name', 'Course', 'Year', 'Purpose', 'Laboratory', 'Date', 'Time In', 'Time Out', 'Duration (min)', 'Reward Points', 'Status']);

        foreach ($reports as $row) {
            fputcsv($output, [
                $row['id'],
                $row['id_number'],
                $row['name'],
                $row['course'],
                $row['year_level'],
                $row['purpose'],
                $row['laboratory'],
                $row['login_date'],
                $row['login_time'],
                $row['logout_time'] ?? '',
                $row['duration_minutes'] ?? 0,
                $row['reward_points_given'] ?? 0,
                $row['status']
            ]);
        }
        fclose($output);
        exit();
    }

    if ($export_type === 'excel') {
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="sit_in_report_' . date('Y-m-d') . '.xls"');

        echo '<html>';
        echo '<head><meta charset="UTF-8"><title>Sit-in Report</title>';
        echo '<style>th{background:#2563eb;color:white;padding:8px;}td{padding:6px;}</style>';
        echo '</head><body>';
        echo '<h2>Sit-in Report</h2>';
        echo '<p>Generated: ' . date('F j, Y g:i A') . '</p>';
        echo '<table border="1" cellpadding="5" cellspacing="0">';
        echo '<tr style="background:#2563eb;color:white;">';
        echo '<th>ID</th><th>ID Number</th><th>Name</th><th>Course</th><th>Year</th><th>Purpose</th><th>Laboratory</th><th>Date</th><th>Time In</th><th>Time Out</th><th>Duration</th><th>Points</th><th>Status</th>';
        echo '</tr>';

        foreach ($reports as $row) {
            $duration_display = $row['duration_minutes'] ? floor($row['duration_minutes'] / 60) . 'h ' . ($row['duration_minutes'] % 60) . 'm' : '—';
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . htmlspecialchars($row['id_number']) . '</td>';
            echo '<td>' . htmlspecialchars($row['name']) . '</td>';
            echo '<td>' . htmlspecialchars($row['course']) . '</td>';
            echo '<td>' . htmlspecialchars($row['year_level']) . '</td>';
            echo '<td>' . htmlspecialchars($row['purpose']) . '</td>';
            echo '<td>' . htmlspecialchars($row['laboratory']) . '</td>';
            echo '<td>' . $row['login_date'] . '</td>';
            echo '<td>' . $row['login_time'] . '</td>';
            echo '<td>' . ($row['logout_time'] ?? '—') . '</td>';
            echo '<td>' . $duration_display . '</td>';
            echo '<td>' . ($row['reward_points_given'] ?? 0) . '</td>';
            echo '<td>' . ucfirst($row['status']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '<p style="margin-top:20px;font-size:11px;color:#666;">Generated by CCS Sit-in System</p>';
        echo '</body></html>';
        exit();
    }

    if ($export_type === 'pdf') {
        ?>
        <!DOCTYPE html>
        <html>

        <head>
            <meta charset="UTF-8">
            <title>Sit-in Report - CCS Sit-in System</title>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }

                body {
                    font-family: 'Segoe UI', 'Roboto', Arial, sans-serif;
                    background: #e2e8f0;
                    padding: 30px;
                }

                @media print {
                    body {
                        background: white;
                        padding: 0;
                        margin: 0;
                    }

                    .no-print {
                        display: none;
                    }

                    .report-card {
                        box-shadow: none;
                        border-radius: 0;
                    }

                    .stat-card {
                        break-inside: avoid;
                    }

                    .data-table tr {
                        break-inside: avoid;
                    }
                }

                .no-print {
                    text-align: center;
                    margin-bottom: 20px;
                    position: sticky;
                    top: 10px;
                    z-index: 100;
                }

                .print-btn,
                .close-btn {
                    padding: 10px 24px;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 600;
                    margin: 0 5px;
                    transition: all 0.2s;
                }

                .print-btn {
                    background: linear-gradient(135deg, #2563eb, #1d4ed8);
                    color: white;
                }

                .print-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
                }

                .close-btn {
                    background: #ef4444;
                    color: white;
                }

                .close-btn:hover {
                    background: #dc2626;
                }

                .report-card {
                    max-width: 1280px;
                    margin: 0 auto;
                    background: white;
                    border-radius: 16px;
                    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
                    overflow: hidden;
                }

                .report-header {
                    background: linear-gradient(135deg, #1e3a5f, #0f2b42);
                    padding: 32px 40px;
                    text-align: center;
                    color: white;
                }

                .report-header h1 {
                    font-size: 28px;
                    font-weight: 700;
                    margin-bottom: 8px;
                }

                .report-header .subtitle {
                    font-size: 14px;
                    opacity: 0.85;
                }

                .report-header .date-generated {
                    font-size: 12px;
                    opacity: 0.7;
                    margin-top: 12px;
                    padding-top: 8px;
                    border-top: 1px solid rgba(255, 255, 255, 0.2);
                    display: inline-block;
                }

                .filter-section {
                    background: #f8fafc;
                    padding: 20px 40px;
                    border-bottom: 1px solid #e2e8f0;
                }

                .filter-section h3 {
                    color: #1e3a5f;
                    font-size: 14px;
                    font-weight: 600;
                    margin-bottom: 12px;
                }

                .filter-badges {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                }

                .filter-badge {
                    background: white;
                    padding: 6px 14px;
                    border-radius: 20px;
                    font-size: 12px;
                    color: #334155;
                    border: 1px solid #e2e8f0;
                }

                .filter-badge strong {
                    color: #2563eb;
                }

                .stats-grid {
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    gap: 20px;
                    padding: 30px 40px;
                    background: white;
                    border-bottom: 1px solid #e2e8f0;
                }

                .stat-card {
                    background: linear-gradient(135deg, #f8fafc, #f1f5f9);
                    border-radius: 16px;
                    padding: 20px;
                    text-align: center;
                    border: 1px solid #e2e8f0;
                }

                .stat-card .stat-value {
                    font-size: 34px;
                    font-weight: 800;
                    margin-bottom: 8px;
                }

                .stat-card .stat-label {
                    font-size: 12px;
                    color: #64748b;
                }

                .stat-card.total .stat-value {
                    color: #2563eb;
                }

                .stat-card.completed .stat-value {
                    color: #10b981;
                }

                .stat-card.active .stat-value {
                    color: #f59e0b;
                }

                .stat-card.duration .stat-value {
                    color: #8b5cf6;
                    font-size: 28px;
                }

                .table-section {
                    padding: 0 40px 40px 40px;
                    background: white;
                }

                .data-table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 12px;
                }

                .data-table th {
                    background: #1e3a5f;
                    color: white;
                    padding: 12px 12px;
                    text-align: left;
                    font-weight: 600;
                }

                .data-table td {
                    padding: 10px 12px;
                    border-bottom: 1px solid #e2e8f0;
                    color: #334155;
                }

                .data-table tr:hover {
                    background: #f8fafc;
                }

                .status-badge {
                    display: inline-block;
                    padding: 4px 12px;
                    border-radius: 20px;
                    font-size: 11px;
                    font-weight: 600;
                }

                .status-completed {
                    background: #d1fae5;
                    color: #065f46;
                }

                .status-active {
                    background: #fed7aa;
                    color: #92400e;
                }

                .report-footer {
                    background: #f8fafc;
                    padding: 16px 40px;
                    text-align: center;
                    font-size: 11px;
                    color: #94a3b8;
                    border-top: 1px solid #e2e8f0;
                }

                .empty-state {
                    text-align: center;
                    padding: 60px;
                    color: #94a3b8;
                }
            </style>
        </head>

        <body>
            <div class="no-print">
                <button class="print-btn" onclick="window.print();">🖨️ Print / Save as PDF</button>
                <button class="close-btn" onclick="window.location.href = 'admin_sitin_reports.php';">✖ Close</button>
            </div>

            <div class="report-card">
                <div class="report-header">
                    <h1>📊 Sit-in Session Report</h1>
                    <div class="subtitle">CCS Sit-in Monitoring System</div>
                    <div class="date-generated">Generated: <?php echo date('F j, Y g:i A'); ?></div>
                </div>

                <div class="filter-section">
                    <h3>📋 Applied Filters</h3>
                    <div class="filter-badges">
                        <span class="filter-badge"><strong>📅 Date:</strong>
                            <?php echo date('M d, Y', strtotime($date_from)); ?> -
                            <?php echo date('M d, Y', strtotime($date_to)); ?></span>
                        <?php if (!empty($purpose)): ?>
                            <span class="filter-badge"><strong>🎯 Purpose:</strong> <?php echo htmlspecialchars($purpose); ?></span>
                        <?php endif; ?>
                        <?php if (!empty($laboratory)): ?>
                            <span class="filter-badge"><strong>🔬 Lab:</strong> <?php echo htmlspecialchars($laboratory); ?></span>
                        <?php endif; ?>
                        <?php if (!empty($status)): ?>
                            <span class="filter-badge"><strong>📌 Status:</strong> <?php echo ucfirst($status); ?></span>
                        <?php endif; ?>
                        <span class="filter-badge"><strong>📊 Records:</strong> <?php echo $total_records; ?></span>
                    </div>
                </div>

                <div class="stats-grid">
                    <div class="stat-card total">
                        <div class="stat-value"><?php echo $total_records; ?></div>
                        <div class="stat-label">Total Sessions</div>
                    </div>
                    <div class="stat-card completed">
                        <div class="stat-value"><?php echo $completed_count; ?></div>
                        <div class="stat-label">Completed</div>
                    </div>
                    <div class="stat-card active">
                        <div class="stat-value"><?php echo $active_count; ?></div>
                        <div class="stat-label">Active</div>
                    </div>
                    <div class="stat-card duration">
                        <div class="stat-value"><?php echo floor($total_duration / 60); ?>h <?php echo $total_duration % 60; ?>m
                        </div>
                        <div class="stat-label">Total Duration</div>
                    </div>
                </div>

                <div class="table-section">
                    <?php if (empty($reports)): ?>
                        <div class="empty-state">
                            <div style="font-size: 48px; margin-bottom: 16px;">📭</div>
                            <h3>No Data Available</h3>
                            <p>Try adjusting your filters or date range</p>
                        </div>
                    <?php else: ?>
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ID Number</th>
                                    <th>Student Name</th>
                                    <th>Purpose</th>
                                    <th>Lab</th>
                                    <th>Date</th>
                                    <th>Time In</th>
                                    <th>Time Out</th>
                                    <th>Duration</th>
                                    <th>Points</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $row):
                                    $duration_display = $row['duration_minutes'] ? floor($row['duration_minutes'] / 60) . 'h ' . ($row['duration_minutes'] % 60) . 'm' : '0m';
                                    ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['id_number']); ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['purpose']); ?></td>
                                        <td><?php echo htmlspecialchars($row['laboratory']); ?></td>
                                        <td><?php echo $row['login_date']; ?></td>
                                        <td><?php echo $row['login_time']; ?></td>
                                        <td><?php echo $row['logout_time'] ?? '—'; ?></td>
                                        <td><?php echo $duration_display; ?></td>
                                        <td><?php echo $row['reward_points_given'] ?? 0; ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                                <?php echo ucfirst($row['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <div class="report-footer">
                    <p>This is a system-generated report. For inquiries, please contact CCS Administration.</p>
                    <p>© <?php echo date('Y'); ?> CCS Sit-in Monitoring System. All rights reserved.</p>
                </div>
            </div>

            <script>
                setTimeout(function () { window.print(); }, 500);
            </script>
        </body>

        </html>
        <?php
        exit();
    }
}
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/admin_navigation.php'; ?>

<style>
    .reports-container {
        min-height: 100vh;
        padding: 1.5rem 24px 48px;
        position: relative;
    }

    .reports-container::before {
        content: '';
        position: fixed;
        inset: 0;
        background:
            radial-gradient(ellipse at 5% 0%, rgba(37, 99, 235, 0.35) 0%, transparent 45%),
            radial-gradient(ellipse at 95% 100%, rgba(14, 165, 233, 0.25) 0%, transparent 45%);
        pointer-events: none;
        z-index: -1;
    }

    .reports-main {
        max-width: 1400px;
        margin: 0 auto;
        position: relative;
        z-index: 2;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 28px;
        padding-bottom: 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.10);
    }

    .page-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: #f1f5f9;
    }

    .date-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 18px;
        background: rgba(10, 18, 40, 0.70);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 999px;
        color: #cbd5e1;
        font-size: 0.875rem;
        backdrop-filter: blur(12px);
    }

    .filter-card {
        background: rgba(10, 18, 40, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 16px;
        backdrop-filter: blur(24px);
        padding: 1.25rem;
        margin-bottom: 1.5rem;
    }

    .filter-title {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: #f1f5f9;
        font-size: 0.9rem;
        font-weight: 600;
        margin-bottom: 1rem;
    }

    .filter-row {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        align-items: flex-end;
    }

    .filter-group {
        flex: 1;
        min-width: 150px;
    }

    .filter-group label {
        display: block;
        color: #64748b;
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        margin-bottom: 0.3rem;
    }

    .filter-group input,
    .filter-group select {
        width: 100%;
        padding: 0.6rem 0.8rem;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        color: #f1f5f9;
        font-size: 0.85rem;
        font-family: inherit;
    }

    .filter-group input:focus,
    .filter-group select:focus {
        outline: none;
        border-color: #0ea5e9;
    }

    .filter-group select option {
        background: #1e293b;
        color: #f1f5f9;
    }

    .btn-filter {
        background: linear-gradient(135deg, #2563eb, #7c3aed);
        color: white;
        border: none;
        padding: 0.6rem 1.5rem;
        border-radius: 10px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.2s;
    }

    .btn-filter:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 20px rgba(37, 99, 235, 0.4);
    }

    .btn-reset {
        background: rgba(255, 255, 255, 0.07);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #94a3b8;
        padding: 0.6rem 1.5rem;
        border-radius: 10px;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.2s;
        text-decoration: none;
    }

    .btn-reset:hover {
        background: rgba(255, 255, 255, 0.12);
        color: #f1f5f9;
    }

    .summary-row {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .summary-card {
        background: rgba(10, 18, 40, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 12px;
        padding: 1rem;
        text-align: center;
    }

    .summary-card .value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #facc15;
    }

    .summary-card .label {
        color: #64748b;
        font-size: 0.7rem;
        margin-top: 0.25rem;
    }

    .export-row {
        display: flex;
        justify-content: flex-end;
        gap: 0.75rem;
        margin-bottom: 1rem;
    }

    .btn-export {
        padding: 0.5rem 1.2rem;
        border-radius: 8px;
        font-size: 0.8rem;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.2s;
    }

    .btn-csv {
        background: rgba(16, 185, 129, 0.15);
        border: 1px solid rgba(16, 185, 129, 0.25);
        color: #6ee7b7;
    }

    .btn-csv:hover {
        background: rgba(16, 185, 129, 0.25);
    }

    .btn-excel {
        background: rgba(16, 185, 129, 0.15);
        border: 1px solid rgba(16, 185, 129, 0.25);
        color: #6ee7b7;
    }

    .btn-excel:hover {
        background: rgba(16, 185, 129, 0.25);
    }

    .btn-pdf {
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.25);
        color: #fca5a5;
    }

    .btn-pdf:hover {
        background: rgba(239, 68, 68, 0.25);
    }

    .table-wrapper {
        overflow-x: auto;
    }

    .reports-table {
        width: 100%;
        border-collapse: collapse;
    }

    .reports-table thead tr {
        background: rgba(255, 255, 255, 0.03);
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .reports-table th {
        padding: 0.75rem;
        text-align: left;
        color: #64748b;
        font-weight: 600;
        font-size: 0.7rem;
        text-transform: uppercase;
        white-space: nowrap;
    }

    .reports-table td {
        padding: 0.75rem;
        color: #cbd5e1;
        font-size: 0.8rem;
        border-bottom: 1px solid rgba(255, 255, 255, 0.04);
    }

    .reports-table tr:hover td {
        background: rgba(255, 255, 255, 0.03);
    }

    .badge-completed {
        background: rgba(14, 165, 233, 0.12);
        border: 1px solid rgba(14, 165, 233, 0.25);
        color: #7dd3fc;
        padding: 0.2rem 0.5rem;
        border-radius: 999px;
        font-size: 0.7rem;
    }

    .badge-active {
        background: rgba(16, 185, 129, 0.12);
        border: 1px solid rgba(16, 185, 129, 0.25);
        color: #6ee7b7;
        padding: 0.2rem 0.5rem;
        border-radius: 999px;
        font-size: 0.7rem;
    }

    .empty-state {
        text-align: center;
        padding: 3rem;
        color: #64748b;
    }

    @media (max-width: 1024px) {
        .summary-row {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 768px) {
        .reports-container {
            padding: 80px 16px 40px;
        }

        .summary-row {
            grid-template-columns: repeat(2, 1fr);
        }

        .filter-row {
            flex-direction: column;
        }

        .filter-group {
            width: 100%;
        }

        .export-row {
            justify-content: center;
            flex-wrap: wrap;
        }
    }
</style>

<div class="reports-container">
    <div class="reports-main">

        <div class="page-header">
            <h1><i class="fas fa-chart-bar" style="color:#0ea5e9;margin-right:8px;"></i>Sit-in Reports</h1>
            <div class="date-badge">
                <i class="far fa-calendar-alt"></i>
                <?php echo date('F j, Y'); ?>
            </div>
        </div>

        <div class="filter-card">
            <div class="filter-title">
                <i class="fas fa-filter"></i> Filter Reports
            </div>
            <form method="GET" action="">
                <div class="filter-row">
                    <div class="filter-group">
                        <label>Date From</label>
                        <input type="date" name="date_from" value="<?php echo $date_from; ?>">
                    </div>
                    <div class="filter-group">
                        <label>Date To</label>
                        <input type="date" name="date_to" value="<?php echo $date_to; ?>">
                    </div>
                    <div class="filter-group">
                        <label>Purpose</label>
                        <select name="purpose">
                            <option value="">All Purposes</option>
                            <?php foreach ($purposes as $p): ?>
                                <option value="<?php echo htmlspecialchars($p['purpose']); ?>" <?php echo $purpose === $p['purpose'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($p['purpose']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Laboratory</label>
                        <select name="laboratory">
                            <option value="">All Labs</option>
                            <?php foreach ($laboratories as $lab): ?>
                                <option value="<?php echo htmlspecialchars($lab['laboratory']); ?>" <?php echo $laboratory === $lab['laboratory'] ? 'selected' : ''; ?>>
                                    Lab <?php echo htmlspecialchars($lab['laboratory']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">All Status</option>
                            <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>Completed
                            </option>
                            <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                        </select>
                    </div>
                    <div class="filter-group" style="display: flex; gap: 0.5rem; align-items: center;">
                        <button type="submit" class="btn-filter"><i class="fas fa-search"></i> Generate</button>
                        <a href="admin_sitin_reports.php" class="btn-reset"><i class="fas fa-times"></i> Reset</a>
                    </div>
                </div>
            </form>
        </div>

        <div class="summary-row">
            <div class="summary-card">
                <div class="value"><?php echo $total_records; ?></div>
                <div class="label">Total Sessions</div>
            </div>
            <div class="summary-card">
                <div class="value"><?php echo $completed_count; ?></div>
                <div class="label">Completed</div>
            </div>
            <div class="summary-card">
                <div class="value"><?php echo $active_count; ?></div>
                <div class="label">Active</div>
            </div>
            <div class="summary-card">
                <div class="value"><?php echo floor($total_duration / 60); ?>h <?php echo $total_duration % 60; ?>m
                </div>
                <div class="label">Total Duration</div>
            </div>
        </div>

        <div class="export-row">
            <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'csv'])); ?>"
                class="btn-export btn-csv">
                <i class="fas fa-file-csv"></i> Export CSV
            </a>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'excel'])); ?>"
                class="btn-export btn-excel">
                <i class="fas fa-file-excel"></i> Export Excel
            </a>
            <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'pdf'])); ?>"
                class="btn-export btn-pdf">
                <i class="fas fa-file-pdf"></i> Export PDF
            </a>
        </div>

        <div class="dash-card"
            style="background: rgba(10,18,40,0.82); border: 1px solid rgba(255,255,255,0.10); border-radius: 16px; backdrop-filter: blur(24px); overflow: hidden;">
            <div class="table-wrapper">
                <table class="reports-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ID Number</th>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year</th>
                            <th>Purpose</th>
                            <th>Lab</th>
                            <th>Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Duration</th>
                            <th>Points</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                            <tr>
                                <td colspan="13">
                                    <div class="empty-state">
                                        <i class="fas fa-database"></i>
                                        <h3>No data available</h3>
                                        <p>Try adjusting your filters or date range.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($reports as $row):
                                $duration = $row['duration_minutes'];
                                $duration_display = $duration ? floor($duration / 60) . 'h ' . ($duration % 60) . 'm' : '—';
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['id_number']); ?></td>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['course']); ?></td>
                                    <td>Year <?php echo htmlspecialchars($row['year_level']); ?></td>
                                    <td><?php echo htmlspecialchars($row['purpose']); ?></td>
                                    <td>Lab <?php echo htmlspecialchars($row['laboratory']); ?></td>
                                    <td><?php echo $row['login_date']; ?></td>
                                    <td><?php echo $row['login_time']; ?></td>
                                    <td><?php echo $row['logout_time'] ?? '—'; ?></td>
                                    <td><?php echo $duration_display; ?></td>
                                    <td><?php echo $row['reward_points_given'] ?? 0; ?></td>
                                    <td>
                                        <span class="badge-<?php echo $row['status']; ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php include '../includes/footer.php'; ?>