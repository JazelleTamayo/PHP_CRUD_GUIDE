<?php
// request_form.php
require_once 'includes/auth.php';
redirectIfNotAuthorized(['Resident', 'Staff']);
$pageTitle = 'New Service Request';
include 'includes/header.php';

$serviceType = $_GET['type'] ?? 'Clearance'; // default
?>
<form method="post" action="save_request.php" class="form">
    <h3>Request Details</h3>

    <?php if (hasRole('Staff')): ?>
        <div class="form-group">
            <label for="resident_id">Resident</label>
            <select name="resident_id" id="resident_id" required>
                <option value="">-- Select Resident --</option>
                <option value="1">Juan Dela Cruz</option>
                <option value="2">Maria Santos</option>
            </select>
        </div>
    <?php else: ?>
        <!-- Resident auto-populated from session -->
        <input type="hidden" name="resident_id" value="<?= $_SESSION['user']['id'] ?>">
    <?php endif; ?>

    <div class="form-group">
        <label for="service_type">Service Type</label>
        <select name="service_type" id="service_type" required onchange="showServiceForm(this.value)">
            <option value="Clearance" <?= $serviceType=='Clearance'?'selected':'' ?>>Barangay Clearance</option>
            <option value="Indigency" <?= $serviceType=='Indigency'?'selected':'' ?>>Certificate of Indigency</option>
            <option value="Reservation" <?= $serviceType=='Reservation'?'selected':'' ?>>Facility Reservation</option>
            <option value="Complaint" <?= $serviceType=='Complaint'?'selected':'' ?>>File a Complaint</option>
        </select>
    </div>

    <div id="clearance_fields" class="service-fields <?= $serviceType=='Clearance'?'':'hidden' ?>">
        <h4>Barangay Clearance</h4>
        <div class="form-group">
            <label for="purpose">Purpose</label>
            <input type="text" name="purpose" id="purpose" placeholder="e.g., Employment, Travel">
        </div>
        <!-- Good standing check will be done server-side -->
    </div>

    <div id="indigency_fields" class="service-fields <?= $serviceType=='Indigency'?'':'hidden' ?>">
        <h4>Certificate of Indigency</h4>
        <div class="form-group">
            <label for="assessment">Assessment Details</label>
            <textarea name="assessment" id="assessment" rows="3" placeholder="Income, household size, etc."></textarea>
        </div>
        <?php if (hasRole(['Secretary', 'Staff'])): ?>
            <!-- Assessor auto-assigned from logged-in user -->
        <?php endif; ?>
    </div>

    <div id="reservation_fields" class="service-fields <?= $serviceType=='Reservation'?'':'hidden' ?>">
        <h4>Facility Reservation</h4>
        <div class="form-group">
            <label for="facility_id">Facility</label>
            <select name="facility_id" id="facility_id">
                <option value="">-- Select --</option>
                <option value="1">Multi-Purpose Hall</option>
                <option value="2">Covered Court</option>
            </select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="res_date">Date</label>
                <input type="date" name="res_date" id="res_date">
            </div>
            <div class="form-group">
                <label for="start_time">Start Time</label>
                <input type="time" name="start_time" id="start_time">
            </div>
            <div class="form-group">
                <label for="end_time">End Time</label>
                <input type="time" name="end_time" id="end_time">
            </div>
        </div>
        <div class="form-group">
            <label for="res_purpose">Purpose of Reservation</label>
            <input type="text" name="res_purpose" id="res_purpose">
        </div>
        <div class="form-group">
            <label for="priority">Priority Level</label>
            <select name="priority" id="priority">
                <option value="Private">Private</option>
                <option value="Community">Community</option>
                <option value="Barangay">Barangay</option>
            </select>
        </div>
    </div>

    <div id="complaint_fields" class="service-fields <?= $serviceType=='Complaint'?'':'hidden' ?>">
        <h4>File a Complaint</h4>
        <div class="form-group">
            <label for="respondent_type">Respondent Type</label>
            <select name="respondent_type" id="respondent_type" onchange="toggleRespondentFields()">
                <option value="resident">Registered Resident</option>
                <option value="nonresident">Non-Resident</option>
            </select>
        </div>
        <div id="respondent_resident" class="form-group">
            <label for="respondent_id">Select Respondent</label>
            <select name="respondent_id" id="respondent_id">
                <option value="">-- Select --</option>
                <option value="3">Pedro Penduko</option>
            </select>
        </div>
        <div id="respondent_nonresident" class="form-group hidden">
            <label for="respondent_name">Full Name</label>
            <input type="text" name="respondent_name" id="respondent_name">
            <label for="respondent_contact">Contact</label>
            <input type="text" name="respondent_contact" id="respondent_contact">
        </div>
        <div class="form-group">
            <label for="incident_date">Incident Date</label>
            <input type="date" name="incident_date" id="incident_date">
        </div>
        <div class="form-group">
            <label for="incident_location">Location</label>
            <input type="text" name="incident_location" id="incident_location" placeholder="e.g., Purok 1">
        </div>
        <div class="form-group">
            <label for="complaint_desc">Description</label>
            <textarea name="complaint_desc" id="complaint_desc" rows="4"></textarea>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Submit Request</button>
</form>

<script>
function showServiceForm(type) {
    document.querySelectorAll('.service-fields').forEach(el => el.classList.add('hidden'));
    document.getElementById(type.toLowerCase() + '_fields').classList.remove('hidden');
}
function toggleRespondentFields() {
    var type = document.getElementById('respondent_type').value;
    document.getElementById('respondent_resident').classList.toggle('hidden', type !== 'resident');
    document.getElementById('respondent_nonresident').classList.toggle('hidden', type !== 'nonresident');
}
// Initialize
showServiceForm('<?= $serviceType ?>');
toggleRespondentFields();
</script>

<?php include 'includes/footer.php'; ?>