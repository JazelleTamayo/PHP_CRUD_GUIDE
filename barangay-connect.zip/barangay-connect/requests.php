<?php
// requests.php
require_once 'includes/auth.php';
redirectIfNotAuthorized(['Resident','Staff','Secretary','Captain']);
$pageTitle = 'Service Requests';
include 'includes/header.php';

$role = getUserRole();

// Mock requests
$requests = [
    ['ref'=>'BRGY-20250313-001', 'resident'=>'Juan Dela Cruz', 'type'=>'Clearance', 'status'=>'Approved', 'date'=>'2025-03-13'],
    ['ref'=>'BRGY-20250313-002', 'resident'=>'Maria Santos', 'type'=>'Indigency', 'status'=>'Pending', 'date'=>'2025-03-13'],
    ['ref'=>'BRGY-20250312-015', 'resident'=>'Pedro Penduko', 'type'=>'Complaint', 'status'=>'For Approval', 'date'=>'2025-03-12'],
];
// If resident, filter by their own ID (mock)
if ($role === 'Resident') {
    $requests = array_filter($requests, function($r) {
        return $r['resident'] === 'Maria Santos'; // assume logged resident is Maria
    });
}
?>
<div class="action-bar">
    <?php if (hasRole(['Resident','Staff'])): ?>
        <a href="request_form.php" class="btn btn-primary">+ New Request</a>
    <?php endif; ?>
    <div class="filter">
        <select name="status">
            <option value="">All Status</option>
            <option>Pending</option>
            <option>For Approval</option>
            <option>Approved</option>
            <option>Released</option>
        </select>
        <button class="btn">Filter</button>
    </div>
</div>

<table class="data-table">
    <thead>
        <tr>
            <th>Reference #</th>
            <th>Resident</th>
            <th>Type</th>
            <th>Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($requests as $r): ?>
        <tr>
            <td><?= $r['ref'] ?></td>
            <td><?= $r['resident'] ?></td>
            <td><?= $r['type'] ?></td>
            <td><?= $r['date'] ?></td>
            <td><span class="badge <?= strtolower(str_replace(' ','',$r['status'])) ?>"><?= $r['status'] ?></span></td>
            <td>
                <a href="request_view.php?ref=<?= $r['ref'] ?>" class="btn-small">View</a>
                <?php if (hasRole(['Staff','Secretary','Captain']) && $r['status']!='Released' && $r['status']!='Cancelled'): ?>
                    <a href="update_request.php?ref=<?= $r['ref'] ?>" class="btn-small">Update</a>
                <?php endif; ?>
                <?php if ($role==='Resident' && $r['status']==='Pending'): ?>
                    <a href="cancel_request.php?ref=<?= $r['ref'] ?>" class="btn-small" onclick="return confirm('Cancel?')">Cancel</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include 'includes/footer.php'; ?>