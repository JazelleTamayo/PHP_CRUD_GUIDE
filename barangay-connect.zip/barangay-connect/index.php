<?php
// index.php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Mock authentication (replace with DB check)
    $users = [
        'resident' => ['id'=>2, 'name'=>'Maria Santos', 'role'=>'Resident', 'pass'=>'res'],
        'staff'    => ['id'=>3, 'name'=>'Anna Reyes', 'role'=>'Staff', 'pass'=>'staff'],
        'secretary'=> ['id'=>4, 'name'=>'Mr. Cruz', 'role'=>'Secretary', 'pass'=>'sec'],
        'captain'  => ['id'=>5, 'name'=>'Capt. Dimagiba', 'role'=>'Captain', 'pass'=>'cap'],
        'admin'    => ['id'=>1, 'name'=>'Sys Admin', 'role'=>'SystemAdmin', 'pass'=>'admin'],
    ];

    $found = false;
    foreach ($users as $key => $u) {
        if ($username === $key && $password === $u['pass']) {
            $_SESSION['user'] = $u;
            $found = true;
            header('Location: dashboard.php');
            exit;
        }
    }
    if (!$found) $error = 'Invalid username or password';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barangay Connect - Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="logo">
                <img src="assets/images/logo.png" alt="Barangay Logo" style="max-width:100px;">
                <h2>Barangay Connect</h2>
                <p>Service Request & Document Tracking System</p>
            </div>
            <?php if ($error): ?>
                <div class="alert error"><?= $error ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
            <div class="demo-credentials">
                <p><strong>Demo credentials:</strong><br>
                resident/res, staff/staff, secretary/sec, captain/cap, admin/admin</p>
            </div>
        </div>
    </div>
</body>
</html>