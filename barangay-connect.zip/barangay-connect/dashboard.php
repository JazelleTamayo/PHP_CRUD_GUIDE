<?php
// dashboard.php
require_once 'includes/auth.php';
redirectIfNotLoggedIn();
$user = $_SESSION['user'];
$role = $user['role'];
$pageTitle = 'Dashboard';
include 'includes/header.php';
?>

<h2><?= $role ?> Dashboard</h2>

<?php if ($role === 'Resident'): ?>
    <!-- Resident Dashboard -->
    <div class="dashboard-cards">
        <div class="card">
            <h3>My Pending Requests</h3>
            <div class="card-number">2</div>
            <a href="requests.php?status=pending">View</a>
        </div>
        <div class="card">
            <h3>My Complaint Status</h3>
            <div class="card-number">1</div>
            <a href="complaints.php">Track</a>
        </div>
        <div class="card">
            <h3>Upcoming Reservations</h3>
            <div class="card-number">1</div>
            <a href="calendar.php">View</a>
        </div>
    </div>
    <div class="quick-actions">
        <h3>Quick Actions</h3>
        <a href="request_form.php" class="btn">New Request</a>
        <a href="complaint_form.php" class="btn">File Complaint</a>
    </div>
    <div class="recent-activity">
        <h3>Recent Updates</h3>
        <ul>
            <li>Clearance #C001 approved on 2025-03-10</li>
            <li>Complaint #CP002 scheduled for mediation on 2025-03-15</li>
        </ul>
    </div>

<?php elseif ($role === 'Staff'): ?>
    <!-- Staff Dashboard -->
    <div class="dashboard-cards">
        <div class="card">
            <h3>Today's Pending Requests</h3>
            <div class="card-number">5</div>
            <a href="requests.php?status=pending">Process</a>
        </div>
        <div class="card">
            <h3>New Registrations Today</h3>
            <div class="card-number">3</div>
            <a href="residents.php?filter=today">View</a>
        </div>
        <div class="card">
            <h3>Documents for Release</h3>
            <div class="card-number">4</div>
            <a href="requests.php?status=approved">Release</a>
        </div>
        <div class="card">
            <h3>Upcoming Reservations</h3>
            <div class="card-number">2</div>
            <a href="calendar.php">Schedule</a>
        </div>
    </div>
    <div class="quick-actions">
        <a href="resident_form.php" class="btn">Register New Resident</a>
        <a href="request_form.php" class="btn">Create Request</a>
        <a href="payments.php" class="btn">Record Payment</a>
    </div>
    <div class="queue-list">
        <h3>Next to Process</h3>
        <table>
            <tr><th>Ref #</th><th>Type</th><th>Resident</th><th>Action</th></tr>
            <tr><td>BRGY-20250313-001</td><td>Clearance</td><td>Juan Luna</td><td><a href="request_form.php?id=1">Process</a></td></tr>
            <tr><td>BRGY-20250313-002</td><td>Indigency</td><td>Maria Clara</td><td><a href="request_form.php?id=2">Process</a></td></tr>
        </table>
    </div>

<?php elseif ($role === 'Secretary'): ?>
    <!-- Secretary Dashboard -->
    <div class="dashboard-cards">
        <div class="card">
            <h3>Requests Pending Approval</h3>
            <div class="card-number">7</div>
            <a href="requests.php?status=for_approval">Review</a>
        </div>
        <div class="card">
            <h3>Complaints Needing Assignment</h3>
            <div class="card-number">3</div>
            <a href="complaints.php?status=pending">Assign</a>
        </div>
        <div class="card">
            <h3>Reservations to Review</h3>
            <div class="card-number">2</div>
            <a href="facilities.php?pending=1">Review</a>
        </div>
    </div>
    <div class="quick-actions">
        <a href="reports.php" class="btn">Generate Reports</a>
    </div>
    <div class="performance">
        <h3>Average Processing Time (This Week)</h3>
        <p>Clearance: 45 mins | Indigency: 2 hrs | Complaints: 3 days</p>
    </div>

<?php elseif ($role === 'Captain'): ?>
    <!-- Captain Dashboard -->
    <div class="dashboard-cards">
        <div class="card">
            <h3>Total Pending Requests</h3>
            <div class="card-number">12</div>
        </div>
        <div class="card">
            <h3>Active Complaints</h3>
            <div class="card-number">5</div>
        </div>
        <div class="card">
            <h3>Today's Collections</h3>
            <div class="card-number">₱1,250</div>
        </div>
        <div class="card">
            <h3>Pending User Approvals</h3>
            <div class="card-number">2</div>
            <a href="users.php?pending=1">Approve</a>
        </div>
    </div>
    <div class="quick-actions">
        <a href="reports.php" class="btn">View All Reports</a>
        <a href="users.php" class="btn">Manage Users</a>
    </div>
    <div class="charts">
        <h3>Monthly Request Trends</h3>
        <!-- Placeholder chart – you can integrate Chart.js later -->
        <div style="height:200px; background:#f0f0f0;">[Chart Placeholder]</div>
    </div>

<?php elseif ($role === 'SystemAdmin'): ?>
    <!-- SystemAdmin Dashboard -->
    <div class="dashboard-cards">
        <div class="card">
            <h3>Database Size</h3>
            <div class="card-number">45 MB</div>
        </div>
        <div class="card">
            <h3>Active Users Today</h3>
            <div class="card-number">8</div>
        </div>
        <div class="card">
            <h3>Log Storage</h3>
            <div class="card-number">12 MB</div>
        </div>
    </div>
    <div class="quick-actions">
        <a href="activity_log.php" class="btn">View Audit Logs</a>
        <a href="backup.php" class="btn">Run Backup</a>
    </div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>