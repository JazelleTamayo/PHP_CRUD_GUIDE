// assets/js/script.js
document.addEventListener('DOMContentLoaded', function() {
    // Any global JS can go here
});