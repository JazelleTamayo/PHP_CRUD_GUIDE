<?php
// includes/header.php
if (!isset($pageTitle)) $pageTitle = 'Barangay Connect';

// Dynamically determine the base URL path
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> | Barangay Connect</title>
    <link rel="stylesheet" href="<?= $basePath ?>/assets/css/style.css">
</head>
<body>
    <div class="app-wrapper">
        <?php include 'sidebar.php'; ?>
        <main class="main-content">
            <header class="top-bar">
                <div class="page-title"><?= $pageTitle ?></div>
                <div class="user-info">
                    <span>Welcome, <?= $_SESSION['user']['name'] ?? 'User' ?> (<?= $_SESSION['user']['role'] ?? '' ?>)</span>
                    <a href="logout.php" class="btn-logout">Logout</a>
                </div>
            </header>
            <div class="content-container">