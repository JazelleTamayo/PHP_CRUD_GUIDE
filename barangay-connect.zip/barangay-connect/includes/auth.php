<?php
// includes/auth.php
session_start();

// Mock user roles for demonstration
// In real app, you'd fetch from DB after login
if (!isset($_SESSION['user'])) {
    // Sample login simulation (remove in production)
    // For demo, we'll set a default user if not logged in
    // $_SESSION['user'] = ['id'=>1, 'name'=>'Juan Dela Cruz', 'role'=>'Resident'];
}

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function getUserRole() {
    return $_SESSION['user']['role'] ?? null;
}

function hasRole($roles) {
    if (!is_array($roles)) $roles = [$roles];
    return in_array(getUserRole(), $roles);
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function redirectIfNotAuthorized($allowedRoles) {
    redirectIfNotLoggedIn();
    if (!hasRole($allowedRoles)) {
        // Optionally show error page
        header('HTTP/1.0 403 Forbidden');
        echo 'Access Denied';
        exit;
    }
}
?>