<?php
// includes/sidebar.php
$role = getUserRole();
?>
<aside class="sidebar">
    <div class="sidebar-logo">
        <h2>Barangay Connect</h2>
    </div>
    <nav class="sidebar-nav">
        <ul>
            <li><a href="dashboard.php"><i class="icon-dashboard"></i> Dashboard</a></li>

            <?php if (hasRole(['Staff', 'Secretary', 'Captain'])): ?>
                <li class="nav-header">Resident Management</li>
                <li><a href="residents.php">Residents</a></li>
                <?php if (hasRole('Staff')): ?>
                    <li><a href="resident_form.php">Add New Resident</a></li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if (hasRole(['Resident', 'Staff', 'Secretary', 'Captain'])): ?>
                <li class="nav-header">Service Requests</li>
                <?php if (hasRole(['Resident', 'Staff'])): ?>
                    <li><a href="request_form.php">New Request</a></li>
                <?php endif; ?>
                <li><a href="requests.php">View Requests</a></li>
            <?php endif; ?>

            <?php if (hasRole(['Resident', 'Staff', 'Secretary', 'Captain'])): ?>
                <li class="nav-header">Complaints</li>
                <?php if (hasRole(['Resident', 'Staff'])): ?>
                    <li><a href="complaint_form.php">File Complaint</a></li>
                <?php endif; ?>
                <li><a href="complaints.php">Complaint List</a></li>
            <?php endif; ?>

            <?php if (hasRole(['Staff', 'Secretary', 'Captain'])): ?>
                <li class="nav-header">Facilities</li>
                <li><a href="facilities.php">Manage Facilities</a></li>
                <?php if (hasRole(['Staff'])): ?>
                    <li><a href="reservation_form.php">New Reservation</a></li>
                <?php endif; ?>
                <li><a href="calendar.php">View Calendar</a></li>
            <?php endif; ?>

            <?php if (hasRole(['Staff', 'Secretary', 'Captain'])): ?>
                <li class="nav-header">Payments</li>
                <li><a href="payments.php">Record Payment</a></li>
                <li><a href="collections.php">Collection Summary</a></li>
            <?php endif; ?>

            <?php if (hasRole(['Secretary', 'Captain'])): ?>
                <li class="nav-header">Reports</li>
                <li><a href="reports.php">Generate Reports</a></li>
            <?php endif; ?>

            <?php if (hasRole('Captain')): ?>
                <li class="nav-header">Administration</li>
                <li><a href="users.php">Manage Users</a></li>
                <li><a href="activity_log.php">Activity Log</a></li>
            <?php endif; ?>

            <?php if (hasRole('SystemAdmin')): ?>
                <li class="nav-header">System Admin</li>
                <li><a href="system.php">System Settings</a></li>
                <li><a href="activity_log.php">Audit Logs</a></li>
                <li><a href="backup.php">Backup</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</aside>