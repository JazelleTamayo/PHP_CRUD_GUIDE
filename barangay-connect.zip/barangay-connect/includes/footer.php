<?php
// includes/footer.php
?>
            </div> <!-- .content-container -->
        </main>
    </div> <!-- .app-wrapper -->
    <script src="assets/js/script.js"></script>
</body>
</html>