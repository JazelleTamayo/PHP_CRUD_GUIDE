<?php
// residents.php
require_once 'includes/auth.php';
redirectIfNotAuthorized(['Staff', 'Secretary', 'Captain']);
$pageTitle = 'Resident Management';
include 'includes/header.php';

// Mock residents data
$residents = [
    ['id'=>1, 'name'=>'Juan Dela Cruz', 'address'=>'Purok 1', 'contact'=>'09171234567', 'status'=>'Active'],
    ['id'=>2, 'name'=>'Maria Santos', 'address'=>'Purok 2', 'contact'=>'09181234567', 'status'=>'Active'],
    ['id'=>3, 'name'=>'Pedro Penduko', 'address'=>'Purok 1', 'contact'=>'09191234567', 'status'=>'Inactive'],
];
?>
<div class="action-bar">
    <?php if (hasRole('Staff')): ?>
        <a href="resident_form.php" class="btn btn-primary">+ Add New Resident</a>
    <?php endif; ?>
    <div class="search-box">
        <input type="text" placeholder="Search name, address, contact...">
        <button class="btn">Search</button>
    </div>
</div>

<table class="data-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Address</th>
            <th>Contact</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($residents as $r): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= $r['name'] ?></td>
            <td><?= $r['address'] ?></td>
            <td><?= $r['contact'] ?></td>
            <td><span class="badge <?= strtolower($r['status']) ?>"><?= $r['status'] ?></span></td>
            <td>
                <a href="resident_view.php?id=<?= $r['id'] ?>" class="btn-small">View</a>
                <?php if (hasRole('Staff')): ?>
                    <a href="resident_form.php?id=<?= $r['id'] ?>" class="btn-small">Edit</a>
                    <a href="resident_form.php?deactivate=<?= $r['id'] ?>" class="btn-small" onclick="return confirm('Deactivate?')">Deactivate</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include 'includes/footer.php'; ?>